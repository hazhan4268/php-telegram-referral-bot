<?php
// Simple liveness probe to verify PHP runs and headers work
header('Content-Type: text/plain; charset=utf-8');
echo "pong\n";
